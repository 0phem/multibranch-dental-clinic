export const MODULES = [
  { no: 1, name: 'User, Role & Access Management', owner: 'Licanda, Celin', roles: ['owner'], area: 'Administration' },
  { no: 2, name: 'Multi-Branch Clinic Management', owner: 'Licanda, Celin', roles: ['owner'], area: 'Administration' },
  { no: 3, name: 'Dentist & Staff Management', owner: 'Licanda, Celin', roles: ['owner'], area: 'Administration' },
  { no: 4, name: 'Patient Records Management', owner: 'Ecal, Richmon', roles: ['staff', 'dentist'], area: 'Clinical' },
  { no: 5, name: 'Treatment & Clinical Workflow Management', owner: 'Ecal, Richmon', roles: ['dentist'], area: 'Clinical' },
  { no: 6, name: 'Core Appointment Booking & Schedule Management', owner: 'Alejo, Hart Jaztin A.', roles: ['patient', 'staff'], area: 'Scheduling' },
  { no: 7, name: 'Smart Scheduling & Conflict Prevention', owner: 'Alejo, Hart Jaztin A.', roles: ['patient', 'staff', 'owner'], area: 'Scheduling' },
  { no: 8, name: 'Patient Check-In Management', owner: 'Alejo, Hart Jaztin A.', roles: ['staff'], area: 'Patient Flow' },
  { no: 9, name: 'Smart Patient Queue Management', owner: 'Alejo, Hart Jaztin A.', roles: ['patient', 'staff', 'dentist'], area: 'Patient Flow' },
  { no: 10, name: 'Waiting-Time & Patient Flow Capacity Management', owner: 'Alejo, Hart Jaztin A.', roles: ['patient', 'staff', 'owner'], area: 'Patient Flow' },
  { no: 11, name: 'Billing & Payment Management', owner: 'Ecal, Richmon', roles: ['staff', 'patient'], area: 'Finance' },
  { no: 12, name: 'HMO Verification & Documentation Management', owner: 'Delos Santos, Joevan', roles: ['staff', 'owner'], area: 'HMO' },
  { no: 13, name: 'HMO Request & Approval Management', owner: 'Delos Santos, Joevan', roles: ['staff', 'owner'], area: 'HMO' },
  { no: 14, name: 'HMO Follow-Up & Escalation Automation', owner: 'Delos Santos, Joevan', roles: ['staff', 'owner'], area: 'HMO' },
  { no: 15, name: 'Staff Workload & Cross-Branch Capacity Automation', owner: 'Licanda, Celin', roles: ['owner', 'staff'], area: 'Operations' },
  { no: 16, name: 'Social Media Inquiry Management', owner: 'Millar, John Yzhekiel', roles: ['staff'], area: 'Communication' },
  { no: 17, name: 'Unified Patient Messaging Management', owner: 'Millar, John Yzhekiel', roles: ['patient', 'staff', 'dentist'], area: 'Communication' },
  { no: 18, name: 'Real-Time Patient Notification Management', owner: 'Millar, John Yzhekiel', roles: ['patient', 'staff'], area: 'Communication' },
  { no: 19, name: 'Digital Prescription Management', owner: 'Ecal, Richmon', roles: ['dentist', 'patient'], area: 'Clinical' },
  { no: 20, name: 'Treatment Follow-Up Scheduling Management', owner: 'Ecal, Richmon', roles: ['dentist', 'staff', 'patient'], area: 'Clinical' },
  { no: 21, name: 'Operational Reporting & Analytics Management', owner: 'Delos Santos, Joevan', roles: ['owner'], area: 'Analytics' },
  { no: 22, name: 'Owner Executive Dashboard & Business Intelligence', owner: 'Licanda, Celin', roles: ['owner'], area: 'Analytics' },
  { no: 23, name: 'Integrated Workflow & Automation Control', owner: 'Delos Santos, Joevan', roles: ['owner'], area: 'Automation' },
  { no: 24, name: 'Referral & Loyalty Management', owner: 'Millar, John Yzhekiel', roles: ['patient', 'staff', 'owner'], area: 'Engagement', pe: true },
  { no: 25, name: 'Marketing, Reactivation & Patient Engagement Management', owner: 'Millar, John Yzhekiel', roles: ['owner', 'staff'], area: 'Engagement', pe: true },
]

export const ROLE_INFO = {
  patient: { label: 'Patient', name: 'Maria Santos', subtitle: 'Patient Portal' },
  staff: { label: 'Staff', name: 'Alyssa Cruz', subtitle: 'Front Desk / Patient Services' },
  dentist: { label: 'Dentist', name: 'Dr. Miguel Reyes', subtitle: 'Clinical Services' },
  owner: { label: 'Owner / Admin', name: 'Dr. Dana Roxas', subtitle: 'Clinic Owner / Administrator' },
}

export const BRANCHES = [
  { id: 'b1', name: 'Branch A', hours: '9:00 AM – 6:00 PM', status: 'Open', services: ['General Dentistry', 'Orthodontics', 'Oral Surgery'], dentists: 3 },
  { id: 'b2', name: 'Branch B', hours: '9:00 AM – 6:00 PM', status: 'Open', services: ['General Dentistry', 'Pediatric Dentistry', 'Teeth Whitening'], dentists: 2 },
  { id: 'b3', name: 'Branch C', hours: '10:00 AM – 7:00 PM', status: 'Open', services: ['General Dentistry', 'TMD / Orofacial Pain', 'Dental Implant'], dentists: 2 },
]

export const DENTISTS = [
  { id: 'd1', name: 'Dr. Miguel Reyes', branch: 'Branch A', specialty: 'General Dentistry', shift: '9:00 AM – 6:00 PM', available: true },
  { id: 'd2', name: 'Dr. Patricia Lim', branch: 'Branch A', specialty: 'Orthodontics', shift: '10:00 AM – 7:00 PM', available: true },
  { id: 'd3', name: 'Dr. Carlo Mendoza', branch: 'Branch B', specialty: 'Pediatric Dentistry', shift: '9:00 AM – 6:00 PM', available: true },
  { id: 'd4', name: 'Dr. Andrea Flores', branch: 'Branch C', specialty: 'Dental Implant', shift: '10:00 AM – 7:00 PM', available: true },
]

export const INITIAL_PATIENTS = [
  { id: 'p1', name: 'Maria Santos', phone: '0917 123 4567', email: 'maria@example.com', hmo: 'MediCare Plus', allergies: 'None', history: 'Routine prophylaxis • 2026-07-12', branch: 'Branch A' },
  { id: 'p2', name: 'John Dela Cruz', phone: '0918 221 9001', email: 'john@example.com', hmo: 'HealthFirst', allergies: 'Penicillin', history: 'Composite restoration • 2026-08-04', branch: 'Branch B' },
  { id: 'p3', name: 'Bianca Ramos', phone: '0920 883 2104', email: 'bianca@example.com', hmo: 'None', allergies: 'None', history: 'Orthodontic adjustment • 2026-09-02', branch: 'Branch A' },
  { id: 'p4', name: 'Paolo Garcia', phone: '0916 444 0310', email: 'paolo@example.com', hmo: 'MediCare Plus', allergies: 'Latex', history: 'Extraction • 2026-08-20', branch: 'Branch C' },
]

export const INITIAL_APPOINTMENTS = [
  { id: 'a1', patientId: 'p1', patient: 'Maria Santos', branch: 'Branch A', dentist: 'Dr. Miguel Reyes', service: 'Oral Prophylaxis', date: '2026-09-19', time: '10:00 AM', status: 'Confirmed' },
  { id: 'a2', patientId: 'p2', patient: 'John Dela Cruz', branch: 'Branch B', dentist: 'Dr. Carlo Mendoza', service: 'Dental Consultation', date: '2026-09-19', time: '11:00 AM', status: 'Confirmed' },
  { id: 'a3', patientId: 'p3', patient: 'Bianca Ramos', branch: 'Branch A', dentist: 'Dr. Patricia Lim', service: 'Orthodontic Adjustment', date: '2026-09-19', time: '1:30 PM', status: 'Confirmed' },
  { id: 'a4', patientId: 'p4', patient: 'Paolo Garcia', branch: 'Branch C', dentist: 'Dr. Andrea Flores', service: 'Follow-Up', date: '2026-09-20', time: '10:30 AM', status: 'Confirmed' },
]

export const INITIAL_QUEUE = [
  { id: 'q1', patientId: 'p1', patient: 'Maria Santos', branch: 'Branch A', dentist: 'Dr. Miguel Reyes', checkedIn: '9:46 AM', status: 'Waiting', position: 1 },
  { id: 'q2', patientId: 'p3', patient: 'Bianca Ramos', branch: 'Branch A', dentist: 'Dr. Patricia Lim', checkedIn: '9:51 AM', status: 'Waiting', position: 1 },
  { id: 'q3', patientId: 'p2', patient: 'John Dela Cruz', branch: 'Branch B', dentist: 'Dr. Carlo Mendoza', checkedIn: '10:02 AM', status: 'Waiting', position: 1 },
]

export const INITIAL_HMO = [
  { id: 'h1', patient: 'Maria Santos', provider: 'MediCare Plus', memberId: 'MC-10082', treatment: 'Oral Prophylaxis', branch: 'Branch A', status: 'Pending', submitted: '2026-09-18 10:15', ageHours: 15, documents: 'Complete', reference: 'HMO-2026-0918-01' },
  { id: 'h2', patient: 'John Dela Cruz', provider: 'HealthFirst', memberId: 'HF-22015', treatment: 'Restoration', branch: 'Branch B', status: 'Missing Documents', submitted: '—', ageHours: 0, documents: 'Incomplete', reference: '—' },
  { id: 'h3', patient: 'Paolo Garcia', provider: 'MediCare Plus', memberId: 'MC-88912', treatment: 'Follow-Up', branch: 'Branch C', status: 'Approved', submitted: '2026-09-17 14:30', ageHours: 0, documents: 'Complete', reference: 'HMO-2026-0917-04' },
]

export const INITIAL_INVOICES = [
  { id: 'inv1', patient: 'Maria Santos', date: '2026-09-12', items: 'Consultation + Oral Prophylaxis', amount: 1800, status: 'Paid', method: 'GCash' },
  { id: 'inv2', patient: 'John Dela Cruz', date: '2026-09-15', items: 'Composite Restoration', amount: 2500, status: 'Pending', method: '—' },
]

export const INITIAL_MESSAGES = [
  { id: 'm1', type: 'Inquiry', patient: 'Prospective Patient', channel: 'Facebook', subject: 'Braces price and schedule', status: 'Open', assigned: 'Alyssa Cruz', updated: '8 min ago' },
  { id: 'm2', type: 'Patient Message', patient: 'Maria Santos', channel: 'Portal', subject: 'Can I move my appointment?', status: 'Open', assigned: 'Alyssa Cruz', updated: '21 min ago' },
  { id: 'm3', type: 'Notification', patient: 'John Dela Cruz', channel: 'SMS', subject: 'HMO documents incomplete', status: 'Delivered', assigned: 'System', updated: '1 hr ago' },
]

export const INITIAL_PRESCRIPTIONS = [
  { id: 'rx1', patient: 'Maria Santos', dentist: 'Dr. Miguel Reyes', medication: 'Ibuprofen 400 mg', instructions: 'Take 1 tablet after meals as needed for pain.', date: '2026-09-12', status: 'Authorized' },
]

export const INITIAL_FOLLOWUPS = [
  { id: 'f1', patient: 'Paolo Garcia', dentist: 'Dr. Andrea Flores', reason: 'Post-extraction review', recommended: '2026-09-20', status: 'Scheduled', appointment: '2026-09-20 • 10:30 AM' },
  { id: 'f2', patient: 'Maria Santos', dentist: 'Dr. Miguel Reyes', reason: 'Routine recall', recommended: '2027-03-12', status: 'Open', appointment: 'Not yet booked' },
]

export const INITIAL_USERS = [
  { id: 'u1', name: 'Dr. Dana Roxas', role: 'Owner / Admin', branch: 'All Branches', active: true },
  { id: 'u2', name: 'Alyssa Cruz', role: 'Receptionist', branch: 'Branch A', active: true },
  { id: 'u3', name: 'Dr. Miguel Reyes', role: 'Dentist', branch: 'Branch A', active: true },
  { id: 'u4', name: 'Dr. Patricia Lim', role: 'Dentist', branch: 'Branch A', active: true },
  { id: 'u5', name: 'Marco Villanueva', role: 'HMO Coordinator', branch: 'Branch B', active: true },
]

export const INITIAL_AUTOMATIONS = [
  { id: 'r1', name: 'Block conflicting appointment slots', event: 'Appointment slot requested', action: 'Validate schedules and return alternatives', enabled: true, module: 'M7' },
  { id: 'r2', name: 'Create queue entry after check-in', event: 'Patient checked in', action: 'Create queue record and recalculate positions', enabled: true, module: 'M8 → M9' },
  { id: 'r3', name: 'Capacity overload alert', event: 'Wait/load threshold exceeded', action: 'Alert front desk/owner and show alternatives', enabled: true, module: 'M10 / M15' },
  { id: 'r4', name: 'HMO overdue follow-up', event: 'Pending HMO reaches threshold', action: 'Create task, notify staff, escalate unresolved case', enabled: true, module: 'M14' },
  { id: 'r5', name: 'Post-treatment handoff', event: 'Treatment marked complete', action: 'Update history; create prescription/follow-up tasks if required', enabled: true, module: 'M5 / M19 / M20' },
  { id: 'r6', name: 'Real-time patient notification', event: 'Appointment/queue/delay/follow-up changes', action: 'Send notification and store delivery result', enabled: true, module: 'M18' },
]

export const INITIAL_CAMPAIGNS = [
  { id: 'c1', name: '6-Month Recall Reactivation', audience: 'Patients overdue for routine recall', status: 'Draft', sent: 0, responses: 0, pe: true },
  { id: 'c2', name: 'Post-Visit Feedback', audience: 'Completed visits in last 7 days', status: 'Active', sent: 84, responses: 32, pe: true },
]

export const SERVICES = [
  'Dental Consultation', 'Oral Prophylaxis', 'Restorative Dentistry', 'Extraction',
  'Orthodontic Adjustment', 'Root Canal Treatment', 'Pediatric Dentistry',
  'Teeth Whitening', 'Dental Implant', 'Oral Surgery', 'TMD / Orofacial Pain', 'Follow-Up'
]

export const NAV = {
  patient: [
    ['dashboard', 'Dashboard'], ['book', 'Book Appointment'], ['appointments', 'My Appointments'], ['billing', 'Billing & Receipts'],
    ['queue', 'Queue & Wait'], ['messages', 'Messages & Notifications'], ['prescriptions', 'Prescriptions'],
    ['followups', 'Follow-Ups'], ['loyalty', 'Referral & Loyalty (PE)']
  ],
  staff: [
    ['dashboard', 'Dashboard'], ['appointments', 'Appointments'], ['checkin', 'Check-In & Queue'], ['capacity', 'Capacity & Workload'],
    ['patients', 'Patient Records'], ['billing', 'Billing & Payments'], ['hmo', 'HMO Management'],
    ['messages', 'Inquiries & Messaging'], ['followups', 'Follow-Ups']
  ],
  dentist: [
    ['dashboard', 'Dashboard'], ['schedule', 'My Schedule'], ['queue', 'Patient Queue'],
    ['patients', 'Patient Charts'], ['treatment', 'Treatment & Notes'], ['prescriptions', 'Prescriptions'],
    ['followups', 'Follow-Ups'], ['messages', 'Messages']
  ],
  owner: [
    ['dashboard', 'Executive Dashboard'], ['branches', 'Branches'], ['staff', 'Staff & Dentists'],
    ['capacity', 'Capacity & Workload'], ['analytics', 'Analytics & Reports'], ['users', 'Users & Access'],
    ['hmo', 'HMO Overview'], ['automation', 'Automation Control'], ['engagement', 'Engagement (PE)'],
    ['modules', '25-Module Coverage']
  ],
}
