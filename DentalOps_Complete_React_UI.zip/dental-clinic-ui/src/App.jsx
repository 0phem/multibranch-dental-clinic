import React, { useEffect, useMemo, useState } from 'react'
import {
  MODULES, ROLE_INFO, BRANCHES, DENTISTS, SERVICES, NAV,
  INITIAL_PATIENTS, INITIAL_APPOINTMENTS, INITIAL_QUEUE, INITIAL_HMO,
  INITIAL_INVOICES, INITIAL_MESSAGES, INITIAL_PRESCRIPTIONS,
  INITIAL_FOLLOWUPS, INITIAL_USERS, INITIAL_AUTOMATIONS, INITIAL_CAMPAIGNS,
} from './data.js'

const peso = new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP', maximumFractionDigits: 0 })
const uid = (prefix = 'id') => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`

function useLocalStorage(key, initial) {
  const [value, setValue] = useState(() => {
    try {
      const saved = localStorage.getItem(key)
      return saved ? JSON.parse(saved) : initial
    } catch { return initial }
  })
  useEffect(() => { localStorage.setItem(key, JSON.stringify(value)) }, [key, value])
  return [value, setValue]
}

const statusTone = (value = '') => {
  const s = value.toLowerCase()
  if (['paid', 'approved', 'confirmed', 'authorized', 'active', 'open'].includes(s)) return 'success'
  if (['pending', 'waiting', 'scheduled', 'draft'].includes(s)) return 'warning'
  if (s.includes('missing') || s.includes('cancel') || s.includes('failed') || s.includes('overload')) return 'danger'
  if (s.includes('complete') || s.includes('delivered') || s.includes('closed')) return 'info'
  return 'neutral'
}

function ModuleBadge({ no, pe = false }) {
  return <span className={`module-badge ${pe ? 'pe' : ''}`}>M{no}{pe ? ' • PE' : ''}</span>
}

function Status({ children }) {
  return <span className={`status ${statusTone(String(children))}`}>{children}</span>
}

function StatCard({ label, value, hint, tone = 'teal' }) {
  return <div className={`stat-card ${tone}`}>
    <div className="stat-label">{label}</div>
    <div className="stat-value">{value}</div>
    {hint && <div className="stat-hint">{hint}</div>}
  </div>
}

function Card({ title, subtitle, actions, children, className = '' }) {
  return <section className={`card ${className}`}>
    {(title || actions) && <div className="card-head">
      <div>{title && <h3>{title}</h3>}{subtitle && <p>{subtitle}</p>}</div>
      {actions && <div className="card-actions">{actions}</div>}
    </div>}
    {children}
  </section>
}

function PageHeader({ title, text, modules = [] }) {
  return <div className="page-header">
    <div><h1>{title}</h1>{text && <p>{text}</p>}</div>
    <div className="page-modules">{modules.map(n => <ModuleBadge key={n} no={n} pe={n >= 24} />)}</div>
  </div>
}

function Empty({ text = 'No records found.' }) {
  return <div className="empty-state">{text}</div>
}

function Table({ columns, rows, keyField = 'id' }) {
  return <div className="table-wrap"><table>
    <thead><tr>{columns.map(c => <th key={c.key}>{c.label}</th>)}</tr></thead>
    <tbody>{rows.map(row => <tr key={row[keyField]}>{columns.map(c => <td key={c.key}>{c.render ? c.render(row) : row[c.key]}</td>)}</tr>)}</tbody>
  </table></div>
}

function Button({ children, variant = 'primary', className = '', ...props }) {
  return <button className={`btn ${variant} ${className}`} {...props}>{children}</button>
}

function Field({ label, children, hint }) {
  return <label className="field"><span>{label}</span>{children}{hint && <small>{hint}</small>}</label>
}

function Login({ onLogin }) {
  const [selected, setSelected] = useState('owner')
  return <div className="login-shell">
    <div className="login-panel">
      <div className="brand big"><div className="brand-mark">D</div><div><strong>DentalOps</strong><span>Dr. Dana Roxas</span></div></div>
      <h1>Multi-Branch Dental Clinic Operations & Automation System</h1>
      <p className="login-copy">Interactive React prototype mapped to the 25 documented BPA modules. Choose a role to enter the demo.</p>
      <div className="role-grid">
        {Object.entries(ROLE_INFO).map(([key, info]) => <button key={key} className={`role-choice ${selected === key ? 'selected' : ''}`} onClick={() => setSelected(key)}>
          <span className="role-icon">{key === 'patient' ? '☺' : key === 'staff' ? '◎' : key === 'dentist' ? '✚' : '◆'}</span>
          <strong>{info.label}</strong><small>{info.subtitle}</small>
        </button>)}
      </div>
      <Button onClick={() => onLogin(selected)} className="login-button">Enter as {ROLE_INFO[selected].label}</Button>
      <div className="login-note">Prototype data is stored locally in your browser. Modules 24–25 are marked Proposed Enhancement (PE).</div>
    </div>
    <div className="login-visual">
      <div className="visual-kicker">BPA PROJECT • GROUP 3 • BSIT 3B</div>
      <div className="visual-title">One system.<br/>Four role experiences.<br/>Twenty-five modules.</div>
      <div className="visual-cards"><div>Scheduling automation</div><div>HMO escalation</div><div>Patient flow</div><div>Executive analytics</div></div>
    </div>
  </div>
}

function Shell({ role, page, setPage, setRole, children }) {
  const info = ROLE_INFO[role]
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark">D</div><div><strong>DentalOps</strong><span>Clinic Automation</span></div></div>
      <nav>{NAV[role].map(([key, label]) => <button key={key} className={page === key ? 'active' : ''} onClick={() => setPage(key)}><span className="nav-dot" />{label}</button>)}</nav>
      <div className="sidebar-footer"><small>Signed in as</small><strong>{info.name}</strong><span>{info.subtitle}</span></div>
    </aside>
    <main className="main-shell">
      <header className="topbar">
        <div><span className="branch-pill">3 branches connected</span></div>
        <div className="top-actions">
          <select value={role} onChange={e => setRole(e.target.value)} aria-label="Switch demo role">
            {Object.entries(ROLE_INFO).map(([key, r]) => <option key={key} value={key}>{r.label}</option>)}
          </select>
          <button className="avatar" title="Demo profile">{info.name.split(' ').map(x => x[0]).slice(0,2).join('')}</button>
          <button className="logout" onClick={() => setRole(null)}>Log out</button>
        </div>
      </header>
      <div className="content">{children}</div>
    </main>
  </div>
}

function Dashboard({ role, appointments, queue, hmo, invoices, messages, branches, dentists }) {
  const todayAppointments = appointments.filter(a => a.status !== 'Cancelled')
  const pendingHmo = hmo.filter(h => h.status === 'Pending').length
  const waiting = queue.filter(q => q.status === 'Waiting').length
  const openMessages = messages.filter(m => m.status === 'Open').length
  const revenue = invoices.filter(i => i.status === 'Paid').reduce((s, i) => s + i.amount, 0)

  if (role === 'patient') return <>
    <PageHeader title="Welcome back, Maria" text="Your appointments, queue status, messages, and follow-ups in one place." modules={[6,9,10,17,18,20]} />
    <div className="stats-grid"><StatCard label="Next appointment" value="Sep 19 • 10:00 AM" hint="Branch A • Dr. Miguel Reyes"/><StatCard label="Queue position" value="#1" hint="Estimated wait: 12 min" tone="blue"/><StatCard label="Open follow-ups" value="1" hint="Routine recall" tone="amber"/><StatCard label="Unread updates" value="2" hint="Messages & notifications" tone="purple"/></div>
    <div className="grid-2">
      <Card title="Upcoming appointment" subtitle="Validated by Smart Scheduling"><div className="appointment-focus"><div className="date-box"><b>19</b><span>SEP</span></div><div><h3>Oral Prophylaxis</h3><p>10:00 AM • Branch A</p><p>Dr. Miguel Reyes</p></div><Status>Confirmed</Status></div></Card>
      <Card title="Live patient flow" subtitle="Queue and wait-time automation"><div className="flow-strip"><div><small>Checked in</small><b>9:46 AM</b></div><span>→</span><div><small>Position</small><b>#1</b></div><span>→</span><div><small>Est. wait</small><b>12 min</b></div></div><div className="notice success">You will receive an automatic update when you are called.</div></Card>
    </div>
  </>

  if (role === 'staff') return <>
    <PageHeader title="Front Desk Dashboard" text="Appointments, arrivals, HMO work, and patient communication requiring attention." modules={[6,7,8,9,10,11,12,13,14,16,17,18,20]} />
    <div className="stats-grid"><StatCard label="Today's appointments" value={todayAppointments.length}/><StatCard label="Waiting patients" value={waiting} tone="blue"/><StatCard label="Pending HMO" value={pendingHmo} tone="amber"/><StatCard label="Open messages" value={openMessages} tone="purple"/></div>
    <div className="grid-2"><Card title="Operational alerts"><div className="alert-list"><div className="alert warning"><b>HMO follow-up due</b><span>Maria Santos • MediCare Plus • pending 15h</span></div><div className="alert info"><b>Queue load normal</b><span>All branches currently below overload threshold</span></div><div className="alert neutral"><b>Social inquiry awaiting reply</b><span>Facebook inquiry about braces</span></div></div></Card><Card title="Today's branch snapshot">{branches.map(b => <div className="metric-row" key={b.id}><span>{b.name}</span><b>{b.status}</b><small>{b.dentists} dentists</small></div>)}</Card></div>
  </>

  if (role === 'dentist') return <>
    <PageHeader title="Clinical Dashboard" text="Your schedule, queue, patient records, treatment, prescriptions, and follow-ups." modules={[4,5,9,17,19,20]} />
    <div className="stats-grid"><StatCard label="Patients today" value="6"/><StatCard label="Waiting for you" value={queue.filter(q => q.dentist === 'Dr. Miguel Reyes' && q.status === 'Waiting').length} tone="blue"/><StatCard label="Open clinical notes" value="1" tone="amber"/><StatCard label="Follow-ups to review" value="2" tone="purple"/></div>
    <div className="grid-2"><Card title="Next patient"><div className="patient-focus"><div className="avatar large">MS</div><div><h3>Maria Santos</h3><p>Oral Prophylaxis • 10:00 AM</p><p>No known allergies</p></div><Status>Waiting</Status></div></Card><Card title="Today's schedule">{todayAppointments.slice(0,4).map(a => <div className="schedule-row" key={a.id}><b>{a.time}</b><div><strong>{a.patient}</strong><small>{a.service}</small></div><Status>{a.status}</Status></div>)}</Card></div>
  </>

  return <>
    <PageHeader title="Executive Dashboard" text="Cross-branch operational indicators, exceptions, workload, HMO, patient flow, and revenue." modules={[15,21,22]} />
    <div className="stats-grid"><StatCard label="Appointments" value={todayAppointments.length} hint="Across 3 branches"/><StatCard label="Live waiting patients" value={waiting} tone="blue"/><StatCard label="Pending HMO cases" value={pendingHmo} tone="amber"/><StatCard label="Recorded paid revenue" value={peso.format(revenue)} tone="purple"/></div>
    <div className="grid-2">
      <Card title="Branch comparison" subtitle="Operational summary"><div className="branch-bars">{branches.map((b, i) => <div key={b.id}><div className="bar-label"><span>{b.name}</span><b>{[78,61,49][i]}% load</b></div><div className="bar-track"><span style={{width:`${[78,61,49][i]}%`}} /></div></div>)}</div></Card>
      <Card title="Priority issues" subtitle="Exception-driven management view"><div className="alert-list"><div className="alert warning"><b>1 HMO case nearing follow-up threshold</b><span>Module 14 automation is active</span></div><div className="alert info"><b>Branch A workload at 78%</b><span>Below configured overload threshold</span></div><div className="alert success"><b>No confirmed scheduling conflicts</b><span>Smart Scheduling validation active</span></div></div></Card>
    </div>
  </>
}

function AppointmentPage({ role, appointments, setAppointments, onBook, toast }) {
  const rows = role === 'patient' ? appointments.filter(a => a.patient === 'Maria Santos') : appointments
  const cancel = id => { setAppointments(xs => xs.map(a => a.id === id ? {...a, status:'Cancelled'} : a)); toast('Appointment cancelled. Slot released automatically.') }
  const confirm = id => { setAppointments(xs => xs.map(a => a.id === id ? {...a, status:'Confirmed'} : a)); toast('Appointment confirmed.') }
  const move = id => { const target=appointments.find(a=>a.id===id); const choices=['9:00 AM','10:00 AM','11:00 AM','1:30 PM','3:00 PM','4:30 PM']; const next=choices.find(t=>t!==target?.time && !appointments.some(a=>a.id!==id&&a.status!=='Cancelled'&&a.dentist===target?.dentist&&a.date===target?.date&&a.time===t)); if(!next){toast('No conflict-free slot is available in the demo day.');return} setAppointments(xs => xs.map(a => a.id === id ? {...a, time:next, status:'Confirmed'} : a)); toast(`Appointment rescheduled to ${next} after conflict validation.`) }
  return <>
    <PageHeader title={role === 'patient' ? 'My Appointments' : 'Appointment Management'} text="Booking lifecycle with smart conflict prevention, rescheduling, cancellation, and automatic calendar updates." modules={[6,7]} />
    <Card title="Appointment calendar" actions={role !== 'patient' && <Button onClick={() => onBook(true)}>New appointment</Button>}>
      <Table rows={rows} columns={[
        {key:'date',label:'Date'},{key:'time',label:'Time'},{key:'patient',label:'Patient'},
        {key:'service',label:'Service'},{key:'branch',label:'Branch'},{key:'dentist',label:'Dentist'},
        {key:'status',label:'Status',render:r=><Status>{r.status}</Status>},
        {key:'action',label:'Actions',render:r=><div className="row-actions">{r.status !== 'Cancelled' && <><Button variant="ghost" onClick={()=>move(r.id)}>Reschedule</Button><Button variant="danger" onClick={()=>cancel(r.id)}>Cancel</Button></>}{r.status === 'Pending' && <Button variant="ghost" onClick={()=>confirm(r.id)}>Confirm</Button>}</div>}
      ]}/>
    </Card>
  </>
}

function BookingPage({ appointments, setAppointments, toast }) {
  const [form, setForm] = useState({ patient:'Maria Santos', branch:'Branch A', service:'Dental Consultation', dentist:'Dr. Miguel Reyes', date:'2026-09-20', time:'10:00 AM' })
  const [conflict, setConflict] = useState(null)
  const times = ['9:00 AM','10:00 AM','11:00 AM','1:30 PM','3:00 PM','4:30 PM']
  const update = e => setForm({...form,[e.target.name]:e.target.value})
  const submit = e => {
    e.preventDefault()
    const hit = appointments.find(a => a.status !== 'Cancelled' && a.dentist === form.dentist && a.date === form.date && a.time === form.time)
    if (hit) { setConflict({ message:`${form.time} conflicts with an existing ${form.dentist} booking.`, alternatives: times.filter(t => !appointments.some(a => a.status !== 'Cancelled' && a.dentist===form.dentist && a.date===form.date && a.time===t)).slice(0,3) }); return }
    const item = { id:uid('a'), patientId:'p1', ...form, status:'Confirmed' }
    setAppointments(xs => [...xs,item]); setConflict(null); toast('Appointment created, slot reserved, and calendar updated.')
  }
  return <>
    <PageHeader title="Book an Appointment" text="Requested slots are checked against branch schedules, dentist availability, and existing appointments before confirmation." modules={[6,7]} />
    <div className="grid-2 booking-grid">
      <Card title="Appointment request"><form className="form-grid" onSubmit={submit}>
        <Field label="Patient"><input name="patient" value={form.patient} onChange={update}/></Field>
        <Field label="Branch"><select name="branch" value={form.branch} onChange={update}>{BRANCHES.map(b=><option key={b.id}>{b.name}</option>)}</select></Field>
        <Field label="Service"><select name="service" value={form.service} onChange={update}>{SERVICES.map(s=><option key={s}>{s}</option>)}</select></Field>
        <Field label="Dentist"><select name="dentist" value={form.dentist} onChange={update}>{DENTISTS.map(d=><option key={d.id}>{d.name}</option>)}</select></Field>
        <Field label="Date"><input type="date" name="date" value={form.date} onChange={update}/></Field>
        <Field label="Preferred time"><select name="time" value={form.time} onChange={update}>{times.map(t=><option key={t}>{t}</option>)}</select></Field>
        <Button type="submit" className="span-2">Validate slot & confirm booking</Button>
      </form></Card>
      <Card title="Smart Scheduling validation" subtitle="Module 7 automation">
        {conflict ? <div className="conflict-box"><b>Conflict detected</b><p>{conflict.message}</p><small>Available alternatives</small><div className="chip-row">{conflict.alternatives.map(t=><button key={t} className="chip" onClick={()=>{setForm({...form,time:t});setConflict(null)}}>{t}</button>)}</div></div> : <div className="validation-panel"><div className="check">✓ Branch schedule checked</div><div className="check">✓ Dentist availability checked</div><div className="check">✓ Existing appointments checked</div><p>Select a slot and submit. Conflicting slots are blocked before confirmation.</p></div>}
      </Card>
    </div>
  </>
}

function QueuePage({ role, queue, setQueue, appointments, setAppointments, toast }) {
  const recalc = list => {
    const counters = {}
    return list.map(q => {
      if (q.status === 'Completed') return q
      const key = `${q.branch}-${q.dentist}`
      counters[key] = (counters[key] || 0) + 1
      return {...q, position:counters[key]}
    })
  }
  const call = id => { setQueue(xs => recalc(xs.map(q => q.id === id ? {...q,status:'Called'} : q))); toast('Patient called. Remaining queue positions recalculated.') }
  const ready = id => { setQueue(xs => xs.map(q => q.id === id ? {...q,status:'Treatment Ready'} : q)); toast('Treatment-ready status published.') }
  const complete = id => { setQueue(xs => recalc(xs.map(q => q.id === id ? {...q,status:'Completed'} : q))); toast('Queue step completed and positions recalculated.') }
  const visible = role === 'patient' ? queue.filter(q=>q.patient==='Maria Santos') : role === 'dentist' ? queue.filter(q=>q.dentist==='Dr. Miguel Reyes') : queue
  return <>
    <PageHeader title={role === 'patient' ? 'Queue & Waiting Time' : 'Smart Patient Queue'} text="Individual queue ordering is kept separate from aggregate wait-time and capacity monitoring." modules={[9,10]} />
    {role === 'patient' && <div className="stats-grid small"><StatCard label="Current position" value={visible[0]?.status==='Completed'?'Done':`#${visible[0]?.position || '—'}`} /><StatCard label="Estimated wait" value={visible.length ? `${Math.max(5,(visible[0]?.position||1)*12)} min`:'—'} tone="blue"/><StatCard label="Assigned dentist" value={visible[0]?.dentist?.replace('Dr. ','') || '—'} tone="purple"/></div>}
    <Card title="Live queue" subtitle="Positions automatically update when a patient is called, moved, or completed.">
      {visible.length ? <Table rows={visible} columns={[
        {key:'position',label:'Position',render:r=>r.status==='Completed'?'—':`#${r.position}`},{key:'patient',label:'Patient'},{key:'branch',label:'Branch'},
        {key:'dentist',label:'Dentist'},{key:'checkedIn',label:'Checked in'},{key:'status',label:'Status',render:r=><Status>{r.status}</Status>},
        ...(role !== 'patient' ? [{key:'actions',label:'Actions',render:r=><div className="row-actions">{r.status==='Waiting'&&<Button variant="ghost" onClick={()=>call(r.id)}>Call</Button>}{r.status==='Called'&&<Button variant="ghost" onClick={()=>ready(r.id)}>Ready</Button>}{r.status==='Treatment Ready'&&<Button onClick={()=>complete(r.id)}>Complete</Button>}</div>}] : [])
      ]}/> : <Empty/>}
    </Card>
  </>
}

function CheckInPage({ appointments, setAppointments, queue, setQueue, toast }) {
  const candidates = appointments.filter(a => !['Cancelled','Completed','Checked In'].includes(a.status))
  const checkIn = a => {
    setAppointments(xs => xs.map(x => x.id===a.id ? {...x,status:'Checked In'} : x))
    if (!queue.some(q=>q.patient===a.patient && q.status!=='Completed')) {
      const same = queue.filter(q=>q.branch===a.branch && q.dentist===a.dentist && q.status!=='Completed').length
      setQueue(xs => [...xs,{id:uid('q'),patientId:a.patientId,patient:a.patient,branch:a.branch,dentist:a.dentist,checkedIn:new Date().toLocaleTimeString([], {hour:'numeric',minute:'2-digit'}),status:'Waiting',position:same+1}])
    }
    toast('Patient checked in. Queue entry created and Smart Queue notified.')
  }
  return <>
    <PageHeader title="Patient Check-In & Queue" text="Arrival is recorded first; queue ordering begins only after the patient is admitted to the Smart Queue." modules={[8,9,10]} />
    <Card title="Expected / walk-in arrivals"><Table rows={candidates} columns={[
      {key:'time',label:'Time'},{key:'patient',label:'Patient'},{key:'service',label:'Service'},{key:'branch',label:'Branch'},{key:'dentist',label:'Dentist'},
      {key:'status',label:'Appointment',render:r=><Status>{r.status}</Status>},{key:'action',label:'Check-in',render:r=><Button onClick={()=>checkIn(r)}>Check in</Button>}
    ]}/></Card>
    <Card title="Active queue" className="top-gap"><Table rows={queue.filter(q=>q.status!=='Completed')} columns={[{key:'position',label:'#'},{key:'patient',label:'Patient'},{key:'dentist',label:'Dentist'},{key:'branch',label:'Branch'},{key:'status',label:'Status',render:r=><Status>{r.status}</Status>}]} /></Card>
  </>
}

function PatientsPage({ role, patients, setPatients, toast }) {
  const [selected, setSelected] = useState(patients[0]?.id)
  const patient = patients.find(p=>p.id===selected)
  const save = e => { e.preventDefault(); const fd=new FormData(e.currentTarget); setPatients(xs=>xs.map(p=>p.id===selected?{...p,phone:fd.get('phone'),hmo:fd.get('hmo'),allergies:fd.get('allergies'),history:fd.get('history')}:p)); toast('Central patient record updated and linked across branches.') }
  return <>
    <PageHeader title={role==='dentist'?'Patient Charts':'Patient Records'} text="One centralized patient record connects history, HMO, treatment, documents, prescriptions, billing, and branch visits." modules={[4]} />
    <div className="records-layout"><Card title="Patients" className="patient-list">{patients.map(p=><button key={p.id} className={selected===p.id?'selected':''} onClick={()=>setSelected(p.id)}><span className="avatar">{p.name.split(' ').map(x=>x[0]).slice(0,2).join('')}</span><span><b>{p.name}</b><small>{p.branch}</small></span></button>)}</Card>
    {patient && <Card title={patient.name} subtitle={`${patient.email} • ${patient.branch}`}><form className="form-grid" onSubmit={save}><Field label="Phone"><input name="phone" defaultValue={patient.phone}/></Field><Field label="HMO"><input name="hmo" defaultValue={patient.hmo}/></Field><Field label="Allergies"><input name="allergies" defaultValue={patient.allergies}/></Field><Field label="Medical / dental & treatment history"><textarea name="history" defaultValue={patient.history}/></Field><Button className="span-2">Save record changes</Button></form></Card>}</div>
  </>
}

function BillingPage({ invoices, setInvoices, toast }) {
  const [show, setShow] = useState(false)
  const pay = id => { setInvoices(xs=>xs.map(i=>i.id===id?{...i,status:'Paid',method:'GCash'}:i)); toast('Payment validated. Receipt generated and visit payment status updated.') }
  const add = e => { e.preventDefault(); const fd=new FormData(e.currentTarget); setInvoices(xs=>[...xs,{id:uid('inv'),patient:fd.get('patient'),date:'2026-09-19',items:fd.get('items'),amount:Number(fd.get('amount')),status:'Pending',method:'—'}]); setShow(false); toast('Bill generated from applicable charges.') }
  return <>
    <PageHeader title="Billing & Payment Management" text="Completed treatment flows into charge review, billing, payment validation, receipt generation, and transaction closure." modules={[11]} />
    <Card title="Transactions" actions={<Button onClick={()=>setShow(!show)}>Generate bill</Button>}>
      {show && <form className="inline-form" onSubmit={add}><input name="patient" placeholder="Patient" required/><input name="items" placeholder="Applicable charges / services" required/><input name="amount" type="number" placeholder="Amount" required/><Button>Create</Button></form>}
      <Table rows={invoices} columns={[{key:'date',label:'Date'},{key:'patient',label:'Patient'},{key:'items',label:'Charges'},{key:'amount',label:'Amount',render:r=>peso.format(r.amount)},{key:'status',label:'Status',render:r=><Status>{r.status}</Status>},{key:'method',label:'Method'},{key:'action',label:'Action',render:r=>r.status==='Pending'?<Button onClick={()=>pay(r.id)}>Post payment</Button>:<Button variant="ghost" onClick={()=>toast('Digital receipt opened.')}>Receipt</Button>}]} />
    </Card>
  </>
}

function HmoPage({ role, hmo, setHmo, toast }) {
  const act = (id, action) => {
    setHmo(xs=>xs.map(h=>h.id!==id?h: action==='verify'?{...h,documents:'Complete',status:'Ready for Submission'}:action==='submit'?{...h,status:'Pending',reference:`HMO-${Date.now().toString().slice(-6)}`,submitted:'2026-09-19 09:00',ageHours:1}:action==='follow'?{...h,status:'Follow-Up Sent',ageHours:h.ageHours+1}:action==='approve'?{...h,status:'Approved',ageHours:0}:h))
    toast(action==='follow'?'Follow-up logged and escalation timer continued.':'HMO case updated.')
  }
  return <>
    <PageHeader title={role==='owner'?'HMO Overview':'HMO Management'} text="Verification, submission, pending timers, follow-up actions, escalation, and provider response history." modules={[12,13,14]} />
    <div className="stats-grid small"><StatCard label="Pending" value={hmo.filter(x=>x.status==='Pending').length}/><StatCard label="Incomplete" value={hmo.filter(x=>x.documents==='Incomplete').length} tone="amber"/><StatCard label="Approved" value={hmo.filter(x=>x.status==='Approved').length} tone="blue"/></div>
    <Card title="HMO cases"><Table rows={hmo} columns={[{key:'patient',label:'Patient'},{key:'provider',label:'Provider'},{key:'treatment',label:'Treatment'},{key:'documents',label:'Documents',render:r=><Status>{r.documents}</Status>},{key:'status',label:'Status',render:r=><Status>{r.status}</Status>},{key:'ageHours',label:'Pending age',render:r=>r.ageHours?`${r.ageHours}h`:'—'},{key:'reference',label:'Reference'},{key:'action',label:'Actions',render:r=><div className="row-actions">{r.documents==='Incomplete'&&<Button variant="ghost" onClick={()=>act(r.id,'verify')}>Complete docs</Button>}{r.status==='Ready for Submission'&&<Button onClick={()=>act(r.id,'submit')}>Submit</Button>}{r.status==='Pending'&&<Button variant={r.ageHours>=12?'danger':'ghost'} onClick={()=>act(r.id,'follow')}>Follow up</Button>}{role==='owner'&&r.status!=='Approved'&&<Button variant="ghost" onClick={()=>act(r.id,'approve')}>Demo approve</Button>}</div>}]} /></Card>
  </>
}

function MessagesPage({ role, messages, setMessages, toast }) {
  const [draft, setDraft] = useState('')
  const send = () => { if(!draft.trim()) return; setMessages(xs=>[{id:uid('m'),type:'Patient Message',patient:role==='patient'?'Maria Santos':'Maria Santos',channel:'Portal',subject:draft,status:'Open',assigned:role==='patient'?'Alyssa Cruz':ROLE_INFO[role].name,updated:'Just now'},...xs]); setDraft(''); toast('Message recorded in unified conversation history.') }
  const close = id => { setMessages(xs=>xs.map(m=>m.id===id?{...m,status:'Closed',updated:'Just now'}:m)); toast('Conversation closed.') }
  return <>
    <PageHeader title={role==='staff'?'Inquiries & Unified Messaging':'Messages & Notifications'} text="Pre-booking inquiries, identified-patient conversations, and system-generated operational notifications remain separate but connected." modules={[16,17,18]} />
    <div className="grid-2 messages-grid">
      <Card title="Conversation / inquiry inbox">{(role==='patient'?messages.filter(m=>m.patient==='Maria Santos'):messages).map(m=><div className="message-row" key={m.id}><div className="message-icon">{m.type==='Notification'?'↗':'✉'}</div><div className="message-copy"><div><b>{m.patient}</b><span>{m.updated}</span></div><strong>{m.subject}</strong><small>{m.channel} • {m.type} • Assigned: {m.assigned}</small></div><div><Status>{m.status}</Status>{role!=='patient'&&m.status==='Open'&&<button className="text-btn" onClick={()=>close(m.id)}>Close</button>}</div></div>)}</Card>
      <Card title="New message"><textarea className="compose" value={draft} onChange={e=>setDraft(e.target.value)} placeholder="Write a message..."/><Button onClick={send}>Send & store history</Button><div className="notice info">Operational appointment, queue, delay, and follow-up changes are sent automatically by Module 18.</div></Card>
    </div>
  </>
}

function PrescriptionsPage({ role, prescriptions, setPrescriptions, toast }) {
  const add = e => { e.preventDefault(); const fd=new FormData(e.currentTarget); setPrescriptions(xs=>[...xs,{id:uid('rx'),patient:fd.get('patient'),dentist:'Dr. Miguel Reyes',medication:fd.get('medication'),instructions:fd.get('instructions'),date:'2026-09-19',status:'Authorized'}]); e.currentTarget.reset(); toast('Prescription authorized, saved, and linked to patient history.') }
  const visible = role==='patient'?prescriptions.filter(r=>r.patient==='Maria Santos'):prescriptions
  return <>
    <PageHeader title="Digital Prescriptions" text="Dentist-authorized prescriptions are stored in the patient record with printable/digital history." modules={[19]} />
    {role==='dentist'&&<Card title="Create prescription"><form className="form-grid" onSubmit={add}><Field label="Patient"><select name="patient">{INITIAL_PATIENTS.map(p=><option key={p.id}>{p.name}</option>)}</select></Field><Field label="Medication"><input name="medication" required placeholder="Medication and strength"/></Field><Field label="Dosage / instructions"><textarea name="instructions" required placeholder="Dosage and patient instructions"/></Field><div/><Button className="span-2">Review & authorize prescription</Button></form></Card>}
    <Card title="Prescription history" className={role==='dentist'?'top-gap':''}>{visible.length?<Table rows={visible} columns={[{key:'date',label:'Date'},{key:'patient',label:'Patient'},{key:'medication',label:'Medication'},{key:'instructions',label:'Instructions'},{key:'dentist',label:'Authorized by'},{key:'status',label:'Status',render:r=><Status>{r.status}</Status>}]} />:<Empty/>}</Card>
  </>
}

function FollowupsPage({ role, followups, setFollowups, toast }) {
  const schedule = id => { setFollowups(xs=>xs.map(f=>f.id===id?{...f,status:'Scheduled',appointment:'2026-09-26 • 2:00 PM'}:f)); toast('Follow-up appointment scheduled and task closed.') }
  const add = e => { e.preventDefault(); const fd=new FormData(e.currentTarget); setFollowups(xs=>[...xs,{id:uid('f'),patient:fd.get('patient'),dentist:'Dr. Miguel Reyes',reason:fd.get('reason'),recommended:fd.get('recommended'),status:'Open',appointment:'Not yet booked'}]); e.currentTarget.reset(); toast('Follow-up scheduling task created and receptionist/patient notified.') }
  const visible=role==='patient'?followups.filter(f=>f.patient==='Maria Santos'):followups
  return <>
    <PageHeader title="Treatment Follow-Ups" text="Clinical follow-up requirements are recorded separately from the actual booking action so return visits are not lost during handoff." modules={[20]} />
    {role==='dentist'&&<Card title="Create follow-up requirement"><form className="inline-form" onSubmit={add}><select name="patient">{INITIAL_PATIENTS.map(p=><option key={p.id}>{p.name}</option>)}</select><input name="reason" placeholder="Reason" required/><input name="recommended" type="date" required/><Button>Create task</Button></form></Card>}
    <Card title="Follow-up tasks" className={role==='dentist'?'top-gap':''}><Table rows={visible} columns={[{key:'patient',label:'Patient'},{key:'dentist',label:'Dentist'},{key:'reason',label:'Reason'},{key:'recommended',label:'Recommended'},{key:'appointment',label:'Appointment'},{key:'status',label:'Status',render:r=><Status>{r.status}</Status>},...((role==='staff'||role==='patient')?[{key:'action',label:'Action',render:r=>r.status==='Open'?<Button onClick={()=>schedule(r.id)}>Book follow-up</Button>:null}]:[])]}/></Card>
  </>
}

function TreatmentPage({ patients, setPatients, prescriptions, setPrescriptions, followups, setFollowups, toast }) {
  const [selected, setSelected] = useState('p1')
  const p=patients.find(x=>x.id===selected)
  const complete = e => { e.preventDefault(); const fd=new FormData(e.currentTarget); const notes=fd.get('notes'); setPatients(xs=>xs.map(x=>x.id===selected?{...x,history:`${x.history}\n${fd.get('plan')} • 2026-09-19 • ${notes}`}:x)); if(fd.get('rx')==='yes') setPrescriptions(xs=>[...xs,{id:uid('rx'),patient:p.name,dentist:'Dr. Miguel Reyes',medication:'To be completed in prescription module',instructions:'Pending detailed entry',date:'2026-09-19',status:'Draft'}]); if(fd.get('follow')==='yes') setFollowups(xs=>[...xs,{id:uid('f'),patient:p.name,dentist:'Dr. Miguel Reyes',reason:'Post-treatment follow-up',recommended:'2026-09-26',status:'Open',appointment:'Not yet booked'}]); toast('Treatment marked complete. Patient history and downstream tasks updated.'); e.currentTarget.reset() }
  return <>
    <PageHeader title="Treatment & Clinical Workflow" text="The system supports documentation and downstream handoffs while clinical judgment remains with the dentist." modules={[5,19,20]} />
    <div className="grid-2"><Card title="Patient"><select value={selected} onChange={e=>setSelected(e.target.value)}>{patients.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select>{p&&<div className="patient-summary"><h3>{p.name}</h3><p><b>Allergies:</b> {p.allergies}</p><p><b>HMO:</b> {p.hmo}</p><p><b>History:</b><br/>{p.history}</p></div>}</Card><Card title="Complete clinical workflow"><form className="form-grid" onSubmit={complete}><Field label="Treatment plan"><input name="plan" placeholder="Planned / completed procedure" required/></Field><Field label="Status"><select><option>In Treatment</option><option>Completed</option></select></Field><Field label="Clinical notes"><textarea name="notes" required placeholder="Clinical notes"/></Field><div/><Field label="Prescription required?"><select name="rx"><option value="no">No</option><option value="yes">Yes</option></select></Field><Field label="Follow-up required?"><select name="follow"><option value="no">No</option><option value="yes">Yes</option></select></Field><Button className="span-2">Mark procedure complete</Button></form></Card></div>
  </>
}

function BranchesPage({ branches, setBranches, toast }) {
  const toggle = id => { setBranches(xs=>xs.map(b=>b.id===id?{...b,status:b.status==='Open'?'Closed':'Open'}:b)); toast('Branch status published and dependent availability synchronized.') }
  const edit=(id,key,value)=>{setBranches(xs=>xs.map(b=>b.id===id?{...b,[key]:key==='services'?value.split(',').map(x=>x.trim()).filter(Boolean):value}:b));toast('Branch changes saved and dependent records synchronized.')}
  return <>
    <PageHeader title="Multi-Branch Clinic Management" text="Branch information, hours, services, status, schedules, and availability are maintained in one reference layer." modules={[2]} />
    <div className="cards-3">{branches.map(b=><Card key={b.id} title={b.name} actions={<Status>{b.status}</Status>}><div className="field compact"><span>Operating hours</span><input defaultValue={b.hours} onBlur={e=>e.target.value!==b.hours&&edit(b.id,'hours',e.target.value)}/></div><div className="field compact"><span>Available services</span><textarea defaultValue={b.services.join(', ')} onBlur={e=>edit(b.id,'services',e.target.value)}/></div><div className="detail-list"><div><span>Available dentists</span><b>{b.dentists}</b></div></div><Button variant={b.status==='Open'?'danger':'primary'} onClick={()=>toggle(b.id)}>{b.status==='Open'?'Set closed':'Reopen branch'}</Button></Card>)}</div>
  </>
}

function StaffPage({ dentists, setDentists, toast }) {
  const toggle=id=>{setDentists(xs=>xs.map(d=>d.id===id?{...d,available:!d.available}:d));toast('Availability changed and synchronized with scheduling/workload modules.')}
  return <>
    <PageHeader title="Dentist & Staff Management" text="Profiles, specialization, branch assignments, shifts, availability, and scheduling references." modules={[3]} />
    <Card title="Dentist schedule & availability"><Table rows={dentists} columns={[{key:'name',label:'Dentist'},{key:'specialty',label:'Specialization'},{key:'branch',label:'Branch'},{key:'shift',label:'Shift'},{key:'available',label:'Availability',render:r=><Status>{r.available?'Available':'Unavailable'}</Status>},{key:'action',label:'Action',render:r=><Button variant="ghost" onClick={()=>toggle(r.id)}>{r.available?'Mark unavailable':'Mark available'}</Button>}]} /></Card>
  </>
}

function CapacityPage({ queue, branches, dentists }) {
  const metrics=branches.map(b=>{const waiting=queue.filter(q=>q.branch===b.name&&q.status!=='Completed').length;const active=dentists.filter(d=>d.branch===b.name&&d.available).length;const est=active?Math.round(waiting*18/active):waiting*30;const load=Math.min(100,Math.round((waiting/Math.max(active,1))*35));return {...b,waiting,active,est,load,overload:est>30||load>80}})
  return <>
    <PageHeader title="Capacity & Workload" text="Live queue demand is compared with active dentist/staff capacity to estimate waits and surface overload before delays become excessive." modules={[10,15]} />
    <div className="cards-3">{metrics.map(m=><Card key={m.id} title={m.name} actions={<Status>{m.overload?'Overload':'Normal'}</Status>}><div className="capacity-number">{m.load}%<span>workload</span></div><div className="detail-list"><div><span>Waiting patients</span><b>{m.waiting}</b></div><div><span>Active dentists</span><b>{m.active}</b></div><div><span>Estimated wait</span><b>{m.est} min</b></div></div><div className="bar-track"><span style={{width:`${m.load}%`}}/></div></Card>)}</div>
  </>
}

function AnalyticsPage({ appointments, queue, hmo, invoices, messages }) {
  const kpis=[['Scheduling',appointments.filter(a=>a.status!=='Cancelled').length,'Active appointment records'],['Queue',queue.filter(q=>q.status!=='Completed').length,'Patients currently in flow'],['HMO',hmo.filter(h=>h.status==='Pending').length,'Cases pending provider response'],['Communication',messages.filter(m=>m.status==='Open').length,'Open inquiry/message threads'],['Revenue',peso.format(invoices.filter(i=>i.status==='Paid').reduce((s,i)=>s+i.amount,0)),'Recorded paid transactions']]
  return <>
    <PageHeader title="Operational Reporting & Analytics" text="Cross-cutting reporting layer for scheduling, queue, workload, HMO, communication, patient flow, and management KPIs." modules={[21,22]} />
    <div className="stats-grid">{kpis.slice(0,4).map(([l,v,h],i)=><StatCard key={l} label={l} value={v} hint={h} tone={['teal','blue','amber','purple'][i]}/>)}</div>
    <div className="grid-2"><Card title="Operational KPI summary"><div className="report-list">{kpis.map(([l,v,h])=><div key={l}><span>{l}<small>{h}</small></span><b>{v}</b></div>)}</div></Card><Card title="Branch / period comparison"><div className="branch-bars">{['Branch A','Branch B','Branch C'].map((b,i)=><div key={b}><div className="bar-label"><span>{b}</span><b>{[84,67,52][i]} activity index</b></div><div className="bar-track"><span style={{width:`${[84,67,52][i]}%`}}/></div></div>)}</div><Button variant="ghost" onClick={()=>window.print()}>Export / print report</Button></Card></div>
  </>
}

function UsersPage({ users, setUsers, toast }) {
  const [show,setShow]=useState(false)
  const toggle=id=>{setUsers(xs=>xs.map(u=>u.id===id?{...u,active:!u.active}:u));toast('Account status changed and access activity logged.')}
  const add=e=>{e.preventDefault();const fd=new FormData(e.currentTarget);setUsers(xs=>[...xs,{id:uid('u'),name:fd.get('name'),role:fd.get('role'),branch:fd.get('branch'),active:true}]);setShow(false);toast('User account created with assigned role and branch access.')}
  return <>
    <PageHeader title="User, Role & Access Management" text="Create and maintain accounts, roles, branch access, status, and permission controls." modules={[1]} />
    <Card title="Authorized accounts" actions={<Button onClick={()=>setShow(!show)}>Create user</Button>}>
      {show&&<form className="inline-form" onSubmit={add}><input name="name" placeholder="Full name" required/><select name="role"><option>Receptionist</option><option>Dentist</option><option>Assistant</option><option>HMO Coordinator</option><option>Clinic Administrator</option></select><select name="branch"><option>Branch A</option><option>Branch B</option><option>Branch C</option><option>All Branches</option></select><Button>Create account</Button></form>}
      <Table rows={users} columns={[{key:'name',label:'User'},{key:'role',label:'Role'},{key:'branch',label:'Branch access'},{key:'active',label:'Account status',render:r=><Status>{r.active?'Active':'Inactive'}</Status>},{key:'action',label:'Action',render:r=><Button variant={r.active?'danger':'primary'} onClick={()=>toggle(r.id)}>{r.active?'Deactivate':'Activate'}</Button>}]} />
    </Card>
  </>
}

function AutomationPage({ rules, setRules, toast }) {
  const toggle=id=>{setRules(xs=>xs.map(r=>r.id===id?{...r,enabled:!r.enabled}:r));toast('Automation rule configuration updated.')}
  return <>
    <PageHeader title="Integrated Workflow & Automation Control" text="Cross-module events are evaluated against approved rules so dependent actions happen automatically and failures remain visible." modules={[23]} />
    <Card title="Automation rules"><Table rows={rules} columns={[{key:'module',label:'Module'},{key:'name',label:'Rule'},{key:'event',label:'Event'},{key:'action',label:'Automated action'},{key:'enabled',label:'Status',render:r=><Status>{r.enabled?'Active':'Disabled'}</Status>},{key:'toggle',label:'Control',render:r=><Button variant="ghost" onClick={()=>toggle(r.id)}>{r.enabled?'Disable':'Enable'}</Button>}]} /></Card>
    <div className="notice info top-gap">Execution results, failures, and staff alerts are treated as a central activity feed in the prototype.</div>
  </>
}

function EngagementPage({ campaigns, setCampaigns, toast }) {
  const launch=id=>{setCampaigns(xs=>xs.map(c=>c.id===id?{...c,status:'Active',sent:c.sent||24}:c));toast('Proposed Enhancement campaign started for the configured target group.')}
  return <>
    <PageHeader title="Patient Engagement — Proposed Enhancements" text="Optional referral/loyalty and marketing/reactivation features are clearly separated from the core client-stated requirements." modules={[24,25]} />
    <div className="notice warning"><b>Proposed Enhancement (PE)</b> — Modules 24 and 25 are optional differentiators and are not represented as interview-derived requirements.</div>
    <div className="grid-2 top-gap"><Card title="Referral & Loyalty (PE)"><div className="loyalty-card"><small>Demo patient</small><h2>Maria Santos</h2><div className="points">240 <span>points</span></div><div className="referral-code">Referral code: MARIA-24A</div><Button onClick={()=>toast('Demo redemption recorded and duplicate-reward validation applied.')}>Redeem 100 points</Button></div></Card><Card title="Marketing & Reactivation (PE)">{campaigns.map(c=><div className="campaign-row" key={c.id}><div><b>{c.name}</b><small>{c.audience}</small></div><Status>{c.status}</Status><div><small>{c.sent} sent • {c.responses} responses</small></div>{c.status==='Draft'&&<Button variant="ghost" onClick={()=>launch(c.id)}>Launch demo</Button>}</div>)}</Card></div>
  </>
}

function LoyaltyPage({ toast }) {
  return <>
    <PageHeader title="Referral & Loyalty" text="Optional Proposed Enhancement for referral identifiers, qualified visits, rewards, balances, redemption, and duplicate prevention." modules={[24]} />
    <div className="notice warning"><b>Proposed Enhancement (PE)</b> — This is optional and does not replace the clinic's core operational workflows.</div>
    <div className="grid-2 top-gap"><Card title="Your loyalty balance"><div className="loyalty-card"><div className="points">240 <span>points</span></div><p>Qualified rewards are applied once after a configured visit/referral condition is verified.</p><Button onClick={()=>toast('Redemption request recorded in loyalty history.')}>Redeem 100 points</Button></div></Card><Card title="Referral code"><div className="referral-big">MARIA-24A</div><p>Share this demo identifier. A reward is applied only after a qualified referral/visit is verified.</p><Button variant="ghost" onClick={()=>navigator.clipboard?.writeText('MARIA-24A')}>Copy code</Button></Card></div>
  </>
}

function ModulesPage() {
  const grouped=MODULES.reduce((acc,m)=>{(acc[m.area] ||= []).push(m);return acc},{})
  return <>
    <PageHeader title="25-Module Coverage" text="UI traceability matrix for the consolidated BPA documentation. Modules 24–25 remain Proposed Enhancements." modules={[]} />
    <div className="module-summary"><b>25</b><span>documented system modules</span><b>4</b><span>main UI personas</span><b>2</b><span>Proposed Enhancements</span></div>
    {Object.entries(grouped).map(([area,mods])=><Card key={area} title={area} className="top-gap"><div className="module-grid">{mods.map(m=><div className="module-tile" key={m.no}><ModuleBadge no={m.no} pe={m.pe}/><strong>{m.name}</strong><small>Owner: {m.owner}</small><div className="role-tags">{m.roles.map(r=><span key={r}>{ROLE_INFO[r]?.label || r}</span>)}</div></div>)}</div></Card>)}
  </>
}

function SchedulePage({ appointments }) {
  const rows=appointments.filter(a=>a.dentist==='Dr. Miguel Reyes'&&a.status!=='Cancelled')
  return <><PageHeader title="My Schedule" text="Validated appointment slots for your assigned clinic schedule." modules={[6,7]}/><Card title="Upcoming appointments"><Table rows={rows} columns={[{key:'date',label:'Date'},{key:'time',label:'Time'},{key:'patient',label:'Patient'},{key:'service',label:'Service'},{key:'branch',label:'Branch'},{key:'status',label:'Status',render:r=><Status>{r.status}</Status>}]} /></Card></>
}

function App() {
  const [role, setRoleState] = useLocalStorage('dentalops-role', null)
  const [page, setPageState] = useState('dashboard')
  const [toasts, setToasts] = useState([])
  const [branches,setBranches]=useLocalStorage('dentalops-branches',BRANCHES)
  const [dentists,setDentists]=useLocalStorage('dentalops-dentists',DENTISTS)
  const [patients,setPatients]=useLocalStorage('dentalops-patients',INITIAL_PATIENTS)
  const [appointments,setAppointments]=useLocalStorage('dentalops-appointments',INITIAL_APPOINTMENTS)
  const [queue,setQueue]=useLocalStorage('dentalops-queue',INITIAL_QUEUE)
  const [hmo,setHmo]=useLocalStorage('dentalops-hmo',INITIAL_HMO)
  const [invoices,setInvoices]=useLocalStorage('dentalops-invoices',INITIAL_INVOICES)
  const [messages,setMessages]=useLocalStorage('dentalops-messages',INITIAL_MESSAGES)
  const [prescriptions,setPrescriptions]=useLocalStorage('dentalops-rx',INITIAL_PRESCRIPTIONS)
  const [followups,setFollowups]=useLocalStorage('dentalops-followups',INITIAL_FOLLOWUPS)
  const [users,setUsers]=useLocalStorage('dentalops-users',INITIAL_USERS)
  const [rules,setRules]=useLocalStorage('dentalops-rules',INITIAL_AUTOMATIONS)
  const [campaigns,setCampaigns]=useLocalStorage('dentalops-campaigns',INITIAL_CAMPAIGNS)

  const toast = message => {
    const id=uid('toast'); setToasts(xs=>[...xs,{id,message}]); setTimeout(()=>setToasts(xs=>xs.filter(t=>t.id!==id)),3200)
  }
  const setRole = r => { setRoleState(r); setPageState('dashboard'); window.location.hash='dashboard' }
  const setPage = p => { setPageState(p); window.location.hash=p }
  useEffect(()=>{
    const sync=()=>{const p=window.location.hash.replace('#','');if(p)setPageState(p)}
    sync();window.addEventListener('hashchange',sync);return()=>window.removeEventListener('hashchange',sync)
  },[])
  useEffect(()=>{ const allowed = role && (NAV[role].some(([p])=>p===page) || (role==='staff' && page==='book')); if(role && !allowed) setPage('dashboard') },[role,page])

  if (!role) return <Login onLogin={setRole}/>

  const shared={appointments,setAppointments,queue,setQueue,hmo,setHmo,invoices,setInvoices,messages,setMessages,prescriptions,setPrescriptions,followups,setFollowups,patients,setPatients,toast}
  let content=null
  if(page==='dashboard') content=<Dashboard role={role} appointments={appointments} queue={queue} hmo={hmo} invoices={invoices} messages={messages} branches={branches} dentists={dentists}/>
  else if(page==='book') content=<BookingPage appointments={appointments} setAppointments={setAppointments} toast={toast}/>
  else if(page==='appointments') content=<AppointmentPage role={role} appointments={appointments} setAppointments={setAppointments} onBook={()=>setPage('book')} toast={toast}/>
  else if(page==='queue') content=<QueuePage role={role} queue={queue} setQueue={setQueue} appointments={appointments} setAppointments={setAppointments} toast={toast}/>
  else if(page==='checkin') content=<CheckInPage appointments={appointments} setAppointments={setAppointments} queue={queue} setQueue={setQueue} toast={toast}/>
  else if(page==='patients') content=<PatientsPage role={role} patients={patients} setPatients={setPatients} toast={toast}/>
  else if(page==='billing') content=<BillingPage invoices={invoices} setInvoices={setInvoices} toast={toast}/>
  else if(page==='hmo') content=<HmoPage role={role} hmo={hmo} setHmo={setHmo} toast={toast}/>
  else if(page==='messages') content=<MessagesPage role={role} messages={messages} setMessages={setMessages} toast={toast}/>
  else if(page==='prescriptions') content=<PrescriptionsPage role={role} prescriptions={prescriptions} setPrescriptions={setPrescriptions} toast={toast}/>
  else if(page==='followups') content=<FollowupsPage role={role} followups={followups} setFollowups={setFollowups} toast={toast}/>
  else if(page==='loyalty') content=<LoyaltyPage toast={toast}/>
  else if(page==='schedule') content=<SchedulePage appointments={appointments}/>
  else if(page==='treatment') content=<TreatmentPage patients={patients} setPatients={setPatients} prescriptions={prescriptions} setPrescriptions={setPrescriptions} followups={followups} setFollowups={setFollowups} toast={toast}/>
  else if(page==='branches') content=<BranchesPage branches={branches} setBranches={setBranches} toast={toast}/>
  else if(page==='staff') content=<StaffPage dentists={dentists} setDentists={setDentists} toast={toast}/>
  else if(page==='capacity') content=<CapacityPage queue={queue} branches={branches} dentists={dentists}/>
  else if(page==='analytics') content=<AnalyticsPage appointments={appointments} queue={queue} hmo={hmo} invoices={invoices} messages={messages}/>
  else if(page==='users') content=<UsersPage users={users} setUsers={setUsers} toast={toast}/>
  else if(page==='automation') content=<AutomationPage rules={rules} setRules={setRules} toast={toast}/>
  else if(page==='engagement') content=<EngagementPage campaigns={campaigns} setCampaigns={setCampaigns} toast={toast}/>
  else if(page==='modules') content=<ModulesPage/>
  else content=<Dashboard role={role} {...shared} branches={branches} dentists={dentists}/>

  return <Shell role={role} page={page} setPage={setPage} setRole={setRole}>{content}<div className="toast-stack">{toasts.map(t=><div key={t.id} className="toast">✓ {t.message}</div>)}</div></Shell>
}

export default App
