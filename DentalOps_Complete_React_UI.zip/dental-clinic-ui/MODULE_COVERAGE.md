# 25-Module UI Coverage

| Module | Process | Main UI area |
|---:|---|---|
| 1 | User, Role & Access Management | Owner/Admin → Users & Access |
| 2 | Multi-Branch Clinic Management | Owner/Admin → Branches |
| 3 | Dentist & Staff Management | Owner/Admin → Staff & Dentists |
| 4 | Patient Records Management | Staff / Dentist → Patient Records / Charts |
| 5 | Treatment & Clinical Workflow Management | Dentist → Treatment & Notes |
| 6 | Core Appointment Booking & Schedule Management | Patient / Staff → Appointment screens |
| 7 | Smart Scheduling & Conflict Prevention | Booking validation / appointment rescheduling |
| 8 | Patient Check-In Management | Staff → Check-In & Queue |
| 9 | Smart Patient Queue Management | Patient / Staff / Dentist → Queue |
| 10 | Waiting-Time & Patient Flow Capacity Management | Queue & Wait / Capacity & Workload |
| 11 | Billing & Payment Management | Staff / Patient → Billing & Receipts |
| 12 | HMO Verification & Documentation Management | Staff / Owner → HMO |
| 13 | HMO Request & Approval Management | Staff / Owner → HMO |
| 14 | HMO Follow-Up & Escalation Automation | Staff / Owner → HMO |
| 15 | Staff Workload & Cross-Branch Capacity Automation | Staff / Owner → Capacity & Workload |
| 16 | Social Media Inquiry Management | Staff → Inquiries & Messaging |
| 17 | Unified Patient Messaging Management | Patient / Staff / Dentist → Messages |
| 18 | Real-Time Patient Notification Management | Messages / notification behavior |
| 19 | Digital Prescription Management | Dentist / Patient → Prescriptions |
| 20 | Treatment Follow-Up Scheduling Management | Dentist / Staff / Patient → Follow-Ups |
| 21 | Operational Reporting & Analytics Management | Owner/Admin → Analytics & Reports |
| 22 | Owner Executive Dashboard & Business Intelligence | Owner/Admin → Executive Dashboard |
| 23 | Integrated Workflow & Automation Control | Owner/Admin → Automation Control |
| 24 | Referral & Loyalty Management **(PE)** | Patient / Owner → Referral & Loyalty / Engagement |
| 25 | Marketing, Reactivation & Patient Engagement Management **(PE)** | Owner/Admin → Engagement |
