#!/bin/bash
cd "$(dirname "$0")"
echo "DentalOps UI"
echo "Installing dependencies..."
npm install || exit 1
echo "Starting Vite..."
npm run dev
