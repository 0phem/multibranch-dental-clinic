# Dental Clinic Operations & Automation UI

React + Vite frontend prototype for the **Web-Based Multi-Branch Dental Clinic Operations and Automation System** prepared for Dr. Dana Roxas.

## What is included

- 4 role-based UI experiences: **Patient, Staff, Dentist, Owner/Admin**
- UI coverage for all **25 documented modules**
- Modules **24–25** clearly labeled **Proposed Enhancement (PE)**
- Working demo interactions using browser `localStorage`
- Appointment conflict detection and alternative slot suggestions
- Appointment reschedule/cancel with calendar state updates
- Patient check-in and automatic queue creation
- Smart queue state changes and position recalculation
- Waiting-time / capacity monitoring view
- Centralized patient records editing
- Billing and payment posting
- HMO verification, submission, pending/follow-up workflows
- Social inquiries, patient messaging, and notifications
- Dentist treatment notes, prescriptions, and follow-up task creation
- Branch / staff availability management
- Owner executive dashboard, analytics, access management, automation rules
- Referral/loyalty and marketing/reactivation PE screens
- 25-module traceability screen

## Run the project

1. Install Node.js 20+.
2. Open a terminal in this folder.
3. Run:

```bash
npm install
npm run dev
```

4. Open the local URL printed by Vite (normally `http://localhost:5173`).

## Demo login

The first screen lets you enter directly as:

- Patient — Maria Santos
- Staff — Alyssa Cruz
- Dentist — Dr. Miguel Reyes
- Owner/Admin — Dr. Dana Roxas

You can also switch demo roles from the top-right role selector.

## Important scope note

This package is a **complete interactive frontend prototype**, not a production backend. Data is mocked and persisted in browser `localStorage` so the workflows can be demonstrated without a database or server.

For a production/full-stack version, the next layer would be authentication, API endpoints, a relational database, secure permission enforcement, audit logs, and real integrations for messaging/payment/HMO services.
